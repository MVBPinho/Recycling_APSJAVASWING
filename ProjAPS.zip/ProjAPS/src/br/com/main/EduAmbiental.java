package br.com.main;

import br.com.view.Logo;

public class EduAmbiental {

	public static void main(String[] args) {
		Logo frame = new Logo();
		frame.setVisible(true);
	}
}
